-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2019 at 01:28 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quotation`
--

-- --------------------------------------------------------

--
-- Table structure for table `consultants`
--

CREATE TABLE `consultants` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `feedback` text COLLATE utf8mb4_unicode_ci,
  `monthly_cost` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_cost` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Compeletion_duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` enum('ar','en','both') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `quotation_type` enum('facebook','instagram','seo','Web_site','mobile_app','mobile_application') COLLATE utf8mb4_unicode_ci NOT NULL,
  `quotation_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `approval` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `seen` int(11) DEFAULT NULL,
  `forward` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `consultants`
--

INSERT INTO `consultants` (`id`, `user_id`, `admin_id`, `feedback`, `monthly_cost`, `total_cost`, `Compeletion_duration`, `language`, `name`, `email`, `phone`, `message`, `quotation_type`, `quotation_code`, `approval`, `created_at`, `updated_at`, `seen`, `forward`) VALUES
(1, 1, NULL, 'ASDasdasdasdasdasdasdasd', '1000', '100000', '10', 'both', 'ahmed', 'ahmed@sabbah.com', '01094741234', 'asdasdasdasdasd', 'instagram', '#15573101493', '1', '2019-05-08 08:09:09', '2019-05-08 08:09:09', 1, 1),
(2, 5, NULL, NULL, NULL, NULL, NULL, NULL, 'user post', 'user@user.com', '01094741234', 'asdasdasdfasdfasdfasdfasdfasdfadfdfgdfgdfgdfgdfgdfg', 'instagram', '#15573158753', '1', '2019-05-08 09:44:35', '2019-05-08 09:44:35', 1, 1),
(3, 5, NULL, NULL, NULL, NULL, NULL, NULL, 'ahmed', 'ahmed_sabbah121@outlook.com', '01094741234', 'asdasdasdasd', 'instagram', '#15573192936', '1', '2019-05-08 10:41:33', '2019-05-08 10:41:33', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `consultants__doctors`
--

CREATE TABLE `consultants__doctors` (
  `id` int(10) UNSIGNED NOT NULL,
  `consultant_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `doctor_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `consultants__images`
--

CREATE TABLE `consultants__images` (
  `id` int(10) UNSIGNED NOT NULL,
  `consultant_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `labels__keys`
--

CREATE TABLE `labels__keys` (
  `id` int(10) UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `labels__values`
--

CREATE TABLE `labels__values` (
  `id` int(10) UNSIGNED NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `language_id` int(11) NOT NULL,
  `key_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(10) UNSIGNED NOT NULL,
  `language` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefix` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ltr',
  `favicon` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `language`, `prefix`, `direction`, `favicon`, `status`, `created_at`, `updated_at`) VALUES
(1, 'English', 'en', 'ltr', '132977259_606231173_bda6ac6e5565b962161be4f66c8868ff-usa-flag-print-map-by-vexels.png', 1, NULL, '2019-03-11 08:37:39'),
(2, 'Arabic', 'ar', 'rtl', '241894286_1815047188_flag-waving-250.png', 1, NULL, '2019-03-11 08:37:38'),
(3, 'Spanish', 'sp', 'ltr', '749388767_914792125_Spain-flag-map-plus-ultra.png', 0, '2019-03-12 11:51:50', '2019-03-13 08:42:24');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2019_02_28_145100_create_settings_table', 1),
(9, '2019_03_03_101006_create_languages_table', 1),
(10, '2019_03_05_114146_create_profil_images_row', 1),
(11, '2019_03_05_151355_create_labels__values_table', 1),
(12, '2019_03_05_151402_create_labels__keys_table', 1),
(13, '2019_03_11_110246_create_viewed_row_for_users', 1),
(14, '2019_03_11_111130_create_ratings_table', 1),
(15, '2019_03_12_103359_create_info_for_users', 1),
(16, '2019_03_17_122214_create_consultants_table', 1),
(17, '2019_03_17_122221_create_consultants__doctors_table', 1),
(18, '2019_03_17_122447_create_consultants__images_table', 1),
(19, '2019_03_17_145757_create_consultant_status_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefix` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` enum('super_admin','admin','user') COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `profile_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `viewed` int(11) DEFAULT '0',
  `about` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `prefix`, `phone`, `email`, `email_verified_at`, `password`, `api_token`, `level`, `remember_token`, `created_at`, `updated_at`, `profile_image`, `viewed`, `about`) VALUES
(1, 'ahmed', 'ahmed', '', 'ahmed@sabbah.com', NULL, '$2y$10$HDB9Sq0LTrduYxf6CNkbq.Yha7PdLrct2PCBEMWK1LWHMq0ixw032', NULL, 'user', 'JHVnZUAPstBzuOpZz6sJAgTLX7uxMunRJJRMPb67DmIb1EzKkbJG5GfQ5423', '2019-05-08 08:03:03', '2019-05-08 08:03:03', NULL, 0, NULL),
(3, 'admin', 'admin', '01094741234', 'admin@admin.com', NULL, '$2y$10$takA.2QeRhMcN6iRtPhEduCqPhyEFcKfy.69DwroG4cleDYw2/6CO', NULL, 'admin', 'DSeR966oNChFDjyhOpoHrQI7SBjobdD5g4TX4UCe6P4RVy9NFBCRa1lgnrbM', '2019-05-08 08:22:21', '2019-05-08 08:22:21', NULL, 0, NULL),
(4, 'Super Admin', 'super-admin', '01094741234', 'super@admin.com', NULL, '$2y$10$eHmczJDIZLsPJHLjWXXl0Ocp9w6xvIAbXZQm3XPO0pgG0diCEJHJW', NULL, 'super_admin', 'IjnRnFDqnKX1BjF1wJpu34ByUUyZGsHZAPXw45yNJoSDEJoOZXxDD3JuZGJa', '2019-05-08 08:25:48', '2019-05-08 08:25:48', NULL, 0, NULL),
(5, 'user', 'user', '01094741234', 'user@user.com', NULL, '$2y$10$EAWZWQbvZxmENBJk3T5rEO6TIlqK3SX01yItPZmNtPYxy.2GgnHnu', NULL, 'user', 'yFwm3oKCSqkxOqOi8YdKwSL51P7oEswKSLMVM19jvx5ZryG4WVKeB68gwf7N', '2019-05-08 09:43:49', '2019-05-08 09:43:49', NULL, 0, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `consultants`
--
ALTER TABLE `consultants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `consultants__doctors`
--
ALTER TABLE `consultants__doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `consultants__images`
--
ALTER TABLE `consultants__images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `labels__keys`
--
ALTER TABLE `labels__keys`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `labels__keys_key_unique` (`key`);

--
-- Indexes for table `labels__values`
--
ALTER TABLE `labels__values`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `languages_prefix_unique` (`prefix`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_prefix_unique` (`prefix`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `consultants`
--
ALTER TABLE `consultants`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `consultants__doctors`
--
ALTER TABLE `consultants__doctors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `consultants__images`
--
ALTER TABLE `consultants__images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `labels__keys`
--
ALTER TABLE `labels__keys`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `labels__values`
--
ALTER TABLE `labels__values`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
